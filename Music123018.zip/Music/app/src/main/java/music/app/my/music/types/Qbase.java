package music.app.my.music.types;

/**
 * Created by saul on 7/27/16.
 */
public class Qbase {


    public Qbase(){

    }
}
